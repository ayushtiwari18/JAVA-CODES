public class RemoveNth {
    public static void main(String args[]) {
        
    }
}

public class BitwiseOperators {
    public static void main(String args[]) {
        int a = 0;
        System.out.println(~a);
    }
}
import java.util.*;

public class DequeInJava {
    public static void main(String args[]) {
        
    }
}

package Arrays;

public class ArraysIntro {
    public static void main(String args[]) {
        //creating an array 

        int marks[] = new int[50];

        int numbers[] = {1, 2, 3};

        int moreNumbers[] = {4, 5, 6};

        String fruits[] = {"apple", "mango", "orange"};

        System.out.println(marks[0]);
        System.out.println(numbers[0]);
        System.out.println(moreNumbers[0]);
        System.out.println(fruits[0]);
    }
}